This package contains some common tasks for fabric.

Including:

install python, virtualenv
install mysql
install apache2